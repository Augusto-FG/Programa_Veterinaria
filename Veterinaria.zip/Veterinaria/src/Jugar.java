public interface Jugar {

	void perseguirCola();
	void buscarPelota();
}
