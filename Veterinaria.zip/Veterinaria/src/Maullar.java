public interface Maullar {

	void maullar();
	void romperCortinas();
}
